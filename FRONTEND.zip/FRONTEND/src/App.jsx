import React from 'react'

export default function App() {
  return (
    <main className="site-shell">
      <iframe
        className="site-frame"
        src="/site/index.html"
        title="Via Norte | Trânsito e Infraestrutura"
      />
    </main>
  )
}
