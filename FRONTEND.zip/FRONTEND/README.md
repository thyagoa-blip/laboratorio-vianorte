# Via Norte — Frontend

Estrutura organizada no padrão Vite + React, conforme a referência enviada.

## Executar
1. Instale o Node.js.
2. Abra esta pasta no VS Code.
3. No terminal, execute `npm install`.
4. Execute `npm run dev`.
5. Abra o endereço local mostrado pelo Vite.

O site original foi mantido em `public/site` e é exibido sem alterações visuais ou de funcionamento.
