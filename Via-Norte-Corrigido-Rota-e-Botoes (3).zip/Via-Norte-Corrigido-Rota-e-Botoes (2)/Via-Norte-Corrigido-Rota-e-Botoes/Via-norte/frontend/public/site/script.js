// Dados do trânsito
const trafficDefaults = [
    { local: "Centro", status: "Intenso", detail: "Trânsito intenso", updated: "14:20" },
    { local: "Martim de Sá", status: "Atenção", detail: "Atenção na via", updated: "14:05" },
    { local: "Indaiá", status: "Normal", detail: "Trânsito normal", updated: "13:50" },
    { local: "Massaguaçu", status: "Intenso", detail: "Trânsito intenso", updated: "14:10" },
    { local: "Perequê-Mirim", status: "Normal", detail: "Trânsito normal", updated: "13:45" },
    { local: "Porto-Novo", status: "Atenção", detail: "Atenção na via", updated: "13:08" },
    { local: "Sumaré", status: "Normal", detail: "Trânsito normal", updated: "14:24" },
    { local: "Praia das Palmeiras", status: "Atenção", detail: "Atenção na via", updated: "13:00" },
    { local: "Tinga", status: "Normal", detail: "Trânsito normal", updated: "13:13" },
    { local: "Golfinho", status: "Normal", detail: "Trânsito normal", updated: "14:22" },
    { local: "Pontal de Santa Marina", status: "Atenção", detail: "Atenção na via", updated: "14:40" },

];
let trafficData = [...trafficDefaults];

// Dados das obras e ocorrências
const worksData = [
    {
        title: "Obra na Av. Atlântica",
        local: "Centro",
        type: "Obra",
        status: "Em andamento",
        date: "25/09/2026",
        description: "Manutenção da via."
    },

    {
        title: "Colissão entre veículos",
        local: "Massaguaçu",
        type: "Acidente",
        status: "Interditada",
        date: "25/09/2026",
        description: "Acidente."
    },

    {
        title: "Interdição na Rua da Praia",
        local: "Martim de Sá",
        type: "Interdição",
        status: "Interditada",
        date: "25/09/2026",
        description: "Evento na orla."
    },
    {
        title: "Acidente na Rod. SP-55",
        local: "Porto Novo",
        type: "Ocorrência",
        status: "Registrada",
        date: "25/09/2026",
        description: "Colisão envolvendo veículos."
    }
];

let filtroTransito = "Todos";
let tipoRegistros = "works";
let ocorrencias = [];
let usuarioAtual = null;
let abaAdmin = "users";
const API_URL = "/api";
let tokenSessao = localStorage.getItem("viaNorteToken") || "";

async function requisicaoAPI(caminho, opcoes = {}) {
    const resposta = await fetch(API_URL + caminho, {
        ...opcoes,
        headers: {
            "Content-Type": "application/json",
            ...(tokenSessao ? { Authorization: "Bearer " + tokenSessao } : {}),
            ...(opcoes.headers || {})
        }
    });
    const dados = await resposta.json().catch(() => ({}));
    if (!resposta.ok) throw new Error(dados.error || "Não foi possível concluir a operação.");
    return dados;
}

async function carregarOcorrencias() {
    try {
        const dados = await requisicaoAPI("/incidents");
        ocorrencias = dados.incidents || [];
        mostrarObras();
    } catch (erro) {
        if (tokenSessao) mostrarMensagem(erro.message);
    }
}

async function carregarTransito() {
    try {
        const dados = await requisicaoAPI("/traffic-status");
        trafficData = dados.trafficStatus || [];
        mostrarTransito();
    } catch (erro) {
        // Sem registros no banco, mantém a lista demonstrativa original.
        if (!trafficData.length) trafficData = [...trafficDefaults];
        if (tokenSessao) mostrarMensagem(erro.message);
        mostrarTransito();
    }
}

// Mostra uma mensagem na tela
function mostrarMensagem(mensagem) {
    const toast = document.getElementById("toast");

    toast.textContent = mensagem;
    toast.classList.remove("hidden");

    setTimeout(function () {
        toast.classList.add("hidden");
    }, 3000);
}

// Troca de página
function mostrarPagina(pagina) {
    const paginas = document.querySelectorAll(".page");

    for (let i = 0; i < paginas.length; i++) {
        if (paginas[i].id === pagina) {
            paginas[i].classList.remove("hidden");
        } else {
            paginas[i].classList.add("hidden");
        }
    }

    const botoes = document.querySelectorAll(".nav-item");

    for (let i = 0; i < botoes.length; i++) {
        if (botoes[i].dataset.page === pagina) {
            botoes[i].classList.add("text-via", "font-bold");
            botoes[i].classList.remove("text-[#7a8995]");
        } else {
            botoes[i].classList.remove("text-via", "font-bold");
            botoes[i].classList.add("text-[#7a8995]");
        }
    }

    if (pagina === "trafficPage") {
        if (usuarioAtual) carregarTransito();
        else mostrarTransito();
    }

    if (pagina === "worksPage") {
        mostrarObras();
    }

    window.scrollTo(0, 0);
}

// Retorna as classes do status
function classeStatus(status) {
    if (status === "Normal" || status === "Registrada") {
        return "bg-[#dff6e9] text-[#137548]";
    }

    if (status === "Atenção" || status === "Em andamento") {
        return "bg-[#fff2cc] text-[#8a6500]";
    }

    return "bg-[#ffe1e1] text-[#a52b2b]";
}

// Evita que textos digitados sejam interpretados como HTML
function protegerTexto(texto) {
    return String(texto).replace(/[&<>"']/g, function (caractere) {
        if (caractere === "&") return "&amp;";
        if (caractere === "<") return "&lt;";
        if (caractere === ">") return "&gt;";
        if (caractere === '"') return "&quot;";
        return "&#39;";
    });
}

// Mostra os locais com trânsito
function mostrarTransito() {
    const pesquisa = document.getElementById("trafficSearch").value.toLowerCase().trim();
    const lista = document.getElementById("trafficList");

    let html = "";

    for (let i = 0; i < trafficData.length; i++) {
        const item = trafficData[i];

        const mesmoFiltro =
            filtroTransito === "Todos" || item.status === filtroTransito;

        const encontrou =
            item.local.toLowerCase().includes(pesquisa);

        if (mesmoFiltro && encontrou) {
            html += `
                <article class="bg-white border border-border rounded-[9px] p-[15px] flex items-center justify-between gap-[15px] max-[480px]:items-start">
                    <div>
                        <h3 class="text-sm m-0 mb-[7px]">${protegerTexto(item.local)}</h3>
                        <span class="inline-block rounded-xl py-1 px-[9px] text-[11px] font-bold ${classeStatus(item.status)}">
                            ${protegerTexto(item.detail)}
                        </span>
                    </div>

                    <div class="text-right text-muted text-[11px] whitespace-nowrap max-[480px]:whitespace-normal max-[480px]:min-w-[85px]">
                        Última atualização<br>
                        <b>${protegerTexto(item.updated || "Agora")}</b>
                        ${item.id && usuarioAtual ? `<div class="mt-2 flex flex-col gap-1"><button data-edit-traffic="${protegerTexto(item.id)}" class="text-via underline">Editar</button><button data-delete-traffic="${protegerTexto(item.id)}" class="text-red-600 underline">Excluir</button></div>` : ""}
                    </div>
                </article>
            `;
        }
    }

    if (html === "") {
        html = `<p class="text-muted leading-[1.5] m-0 mb-5">Nenhum local encontrado.</p>`;
    }

    lista.innerHTML = html;
}

// Mostra as obras ou ocorrências
function mostrarObras() {
    const pesquisa = document.getElementById("worksSearch").value.toLowerCase().trim();
    const lista = document.getElementById("worksList");

    let html = "";

    // Mostra obras
    if (tipoRegistros === "works") {
        for (let i = 0; i < worksData.length; i++) {
            const item = worksData[i];

            if (item.type === "Ocorrência") {
                continue;
            }

            const texto = (
                item.title + " " +
                item.local + " " +
                item.description
            ).toLowerCase();

            if (texto.includes(pesquisa)) {
                html += criarRegistro(item);
            }
        }
    }

    // Mostra ocorrências
    else {
        for (let i = 0; i < worksData.length; i++) {
            const item = worksData[i];

            if (item.type === "Ocorrência") {
                const texto = (
                    item.title + " " +
                    item.local + " " +
                    item.description
                ).toLowerCase();

                if (texto.includes(pesquisa)) {
                    html += criarRegistro(item);
                }
            }
        }

        for (let i = 0; i < ocorrencias.length; i++) {
            const item = ocorrencias[i];

            const texto = (
                item.title + " " +
                item.local + " " +
                item.description
            ).toLowerCase();

            if (texto.includes(pesquisa)) {
                html += criarRegistro(item);
            }
        }
    }

    if (html === "") {
        html = `<p class="text-muted leading-[1.5] m-0 mb-5">Nenhum registro encontrado.</p>`;
    }

    lista.innerHTML = html;
}

// Cria o HTML de uma obra ou ocorrência
function criarRegistro(item) {
    return `
        <article class="bg-white border border-border rounded-[9px] p-[15px] flex items-center justify-between gap-[15px] max-[480px]:items-start">
            <div>
                <h3 class="text-sm m-0 mb-[7px]">${protegerTexto(item.title)}</h3>
                <p class="my-1 text-muted text-xs">
                    Local: ${protegerTexto(item.local)}
                </p>
                <p class="my-1 text-muted text-xs">
                    ${protegerTexto(item.description)}
                </p>
                <span class="inline-block rounded-xl py-1 px-[9px] text-[11px] font-bold ${classeStatus(item.status)}">
                    ${protegerTexto(item.status)}
                </span>
            </div>

            <div class="text-right text-muted text-[11px] whitespace-nowrap max-[480px]:whitespace-normal max-[480px]:min-w-[85px]">
                ${protegerTexto(item.date || "Hoje")}
                ${item.id && usuarioAtual ? `<div class="mt-2 flex flex-col gap-1"><button data-edit-incident="${protegerTexto(item.id)}" class="text-via underline">Editar</button><button data-delete-incident="${protegerTexto(item.id)}" class="text-red-600 underline">Excluir</button></div>` : ""}
            </div>
        </article>
    `;
}


// LOGIN
document.getElementById("loginForm").addEventListener("submit", async function (evento) {
    evento.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    try {
        const dados = await requisicaoAPI("/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, password })
        });
        tokenSessao = dados.token;
        usuarioAtual = dados.user;
        localStorage.setItem("viaNorteToken", tokenSessao);
        atualizarAcesso();
        document.getElementById("loginView").classList.add("hidden");
        document.getElementById("mainView").classList.remove("hidden");
        mostrarPagina("homePage");
        await carregarOcorrencias();
        await carregarTransito();
        mostrarMensagem("Login realizado com sucesso!");
    } catch (erro) {
        mostrarMensagem(erro.message);
    }
});

// Alterna entre entrar e criar uma conta.
document.getElementById("showRegister").addEventListener("click", function () {
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("registerForm").classList.remove("hidden");
});

document.getElementById("showLogin").addEventListener("click", function () {
    document.getElementById("registerForm").classList.add("hidden");
    document.getElementById("loginForm").classList.remove("hidden");
});

// Cria uma conta nova pelo backend e entra no sistema automaticamente.
document.getElementById("registerForm").addEventListener("submit", async function (evento) {
    evento.preventDefault();
    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value;
    const confirmPassword = document.getElementById("registerConfirmPassword").value;

    if (password !== confirmPassword) {
        mostrarMensagem("As senhas não coincidem.");
        return;
    }

    try {
        const dados = await requisicaoAPI("/auth/register", {
            method: "POST",
            body: JSON.stringify({ name, email, password })
        });
        tokenSessao = dados.token;
        usuarioAtual = dados.user;
        localStorage.setItem("viaNorteToken", tokenSessao);
        atualizarAcesso();
        this.reset();
        document.getElementById("loginView").classList.add("hidden");
        document.getElementById("mainView").classList.remove("hidden");
        mostrarPagina("homePage");
        await carregarOcorrencias();
        await carregarTransito();
        mostrarMensagem("Conta criada! Bem-vindo(a) ao Via Norte.");
    } catch (erro) {
        mostrarMensagem(erro.message);
    }
});

// Mostrar ou esconder senha
document.getElementById("togglePassword").addEventListener("click", function () {
    const senha = document.getElementById("password");

    if (senha.type === "password") {
        senha.type = "text";
    } else {
        senha.type = "password";
    }
});

// Esqueci minha senha
document.getElementById("forgotPassword").addEventListener("click", async function () {
    const email = prompt("Informe o e-mail cadastrado:");
    if (!email) return;
    try {
        const r = await requisicaoAPI("/auth/forgot", { method: "POST", body: JSON.stringify({ email }) });
        alert(r.message);
        const code = prompt("Digite o código exibido no terminal onde o servidor está rodando:");
        if (!code) return;
        const password = prompt("Digite sua nova senha (mínimo 8 caracteres):");
        if (!password) return;
        await requisicaoAPI("/auth/reset", { method: "POST", body: JSON.stringify({ email, code, password }) });
        mostrarMensagem("Senha alterada! Faça login com a nova senha.");
    } catch (e) { mostrarMensagem(e.message); }
});

// Sair
document.getElementById("logoutBtn").addEventListener("click", function () {
    tokenSessao = "";
    usuarioAtual = null;
    document.getElementById("adminNav").classList.add("hidden");
    localStorage.removeItem("viaNorteToken");
    document.getElementById("mainView").classList.add("hidden");
    document.getElementById("loginView").classList.remove("hidden");
    document.getElementById("loginForm").reset();
});

// Botões de navegação
const botoesPagina = document.querySelectorAll("[data-page]");

for (let i = 0; i < botoesPagina.length; i++) {
    botoesPagina[i].addEventListener("click", function () {
        mostrarPagina(this.dataset.page);
    });
}


// FILTROS DO TRÂNSITO
document.getElementById("trafficFilters").addEventListener("click", function (evento) {
    const botao = evento.target.closest("[data-filter]");

    if (!botao) {
        return;
    }

    filtroTransito = botao.dataset.filter;

    const botoes = document.querySelectorAll("#trafficFilters .chip");

    for (let i = 0; i < botoes.length; i++) {
        if (botoes[i] === botao) {
            botoes[i].classList.add("bg-via", "text-white", "border-via", "active");
            botoes[i].classList.remove("bg-white", "text-[#465664]", "border-border");
        } else {
            botoes[i].classList.remove("bg-via", "text-white", "border-via", "active");
            botoes[i].classList.add("bg-white", "text-[#465664]", "border-border");
        }
    }

    mostrarTransito();
});

// Pesquisa de trânsito
document.getElementById("trafficSearch").addEventListener("input", function () {
    mostrarTransito();
});

// Pesquisa de obras
document.getElementById("worksSearch").addEventListener("input", function () {
    mostrarObras();
});


// BOTÕES DE OBRAS E OCORRÊNCIAS
const botoesTipo = document.querySelectorAll("[data-kind]");

for (let i = 0; i < botoesTipo.length; i++) {
    botoesTipo[i].addEventListener("click", function () {
        tipoRegistros = this.dataset.kind;

        for (let j = 0; j < botoesTipo.length; j++) {
            if (botoesTipo[j] === this) {
                botoesTipo[j].classList.add("bg-via", "text-white");
                botoesTipo[j].classList.remove("bg-transparent", "text-[#536574]");
            } else {
                botoesTipo[j].classList.remove("bg-via", "text-white");
                botoesTipo[j].classList.add("bg-transparent", "text-[#536574]");
            }
        }

        mostrarObras();
    });
}


// CONTADOR DE CARACTERES
document.getElementById("incidentDescription").addEventListener("input", function () {
    document.getElementById("charCount").textContent = this.value.length;
});


// FORMULÁRIO DE OCORRÊNCIA
document.getElementById("incidentForm").addEventListener("submit", async function (evento) {
    evento.preventDefault();

    const dadosOcorrencia = {
        type: document.getElementById("incidentType").value,
        local: document.getElementById("incidentLocation").value.trim(),
        date: document.getElementById("incidentDate").value,
        time: document.getElementById("incidentTime").value,
        description: document.getElementById("incidentDescription").value.trim()
    };

    try {
        const resposta = await requisicaoAPI("/incidents", {
            method: "POST",
            body: JSON.stringify(dadosOcorrencia)
        });
        ocorrencias.unshift(resposta.incident);
        this.reset();
        document.getElementById("charCount").textContent = "0";
        mostrarMensagem("Ocorrência salva no banco de dados do servidor!");
        tipoRegistros = "incidents";
        mostrarPagina("worksPage");
        for (let i = 0; i < botoesTipo.length; i++) {
            if (botoesTipo[i].dataset.kind === "incidents") {
                botoesTipo[i].classList.add("bg-via", "text-white");
                botoesTipo[i].classList.remove("bg-transparent", "text-[#536574]");
            } else {
                botoesTipo[i].classList.remove("bg-via", "text-white");
                botoesTipo[i].classList.add("bg-transparent", "text-[#536574]");
            }
        }
        mostrarObras();
    } catch (erro) {
        mostrarMensagem(erro.message);
    }
});



// Controle de acesso, perfil e painel administrativo
function atualizarAcesso() {
    const admin = usuarioAtual && usuarioAtual.role === "admin";
    document.getElementById("adminNav").classList.toggle("hidden", !admin);
    if (usuarioAtual) {
        document.getElementById("profileName").value = usuarioAtual.name || "";
        document.getElementById("profileEmail").value = usuarioAtual.email || "";
    }
}
document.getElementById("profileForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    try {
        const body = { name: document.getElementById("profileName").value.trim(), email: document.getElementById("profileEmail").value.trim(), password: document.getElementById("profilePassword").value };
        const r = await requisicaoAPI("/auth/me", { method:"PATCH", body:JSON.stringify(body) });
        usuarioAtual = r.user; document.getElementById("profilePassword").value = ""; atualizarAcesso();
        mostrarMensagem("Dados da conta atualizados.");
    } catch(err) { mostrarMensagem(err.message); }
});
document.getElementById("adminUsersTab").addEventListener("click", () => { abaAdmin="users"; carregarPainelAdmin(); });
document.getElementById("adminIncidentsTab").addEventListener("click", () => { abaAdmin="incidents"; carregarPainelAdmin(); });
async function carregarPainelAdmin() {
    if (!usuarioAtual || usuarioAtual.role !== "admin") return;
    const area = document.getElementById("adminList");
    try {
        if (abaAdmin === "users") {
            const r = await requisicaoAPI("/users");
            area.innerHTML = r.users.map(u => `<article class="bg-white border border-border rounded-lg p-4">
              <b>${protegerTexto(u.name)}</b><p class="text-muted text-xs">${protegerTexto(u.email)} · ${u.role === "admin" ? "Administrador" : "Usuário"}</p>
              <div class="flex gap-3 mt-2"><button data-user-edit="${protegerTexto(u.id)}" class="text-via underline">Editar</button><button data-user-delete="${protegerTexto(u.id)}" class="text-red-600 underline">Excluir</button></div></article>`).join("") || "<p>Nenhum usuário.</p>";
        } else {
            const r = await requisicaoAPI("/incidents");
            // Mantém a lista local sincronizada para que os botões Editar/Excluir
            // do painel administrativo encontrem a ocorrência selecionada.
            ocorrencias = r.incidents || [];
            area.innerHTML = ocorrencias.map(i => `<article class="bg-white border border-border rounded-lg p-4">
              <b>${protegerTexto(i.title)}</b><p class="text-muted text-xs">${protegerTexto(i.date)} ${protegerTexto(i.time)} · ${protegerTexto(i.local)}</p>
              <p class="my-2">${protegerTexto(i.description)}</p><div class="flex gap-3"><button data-edit-incident="${protegerTexto(i.id)}" class="text-via underline">Editar</button><button data-delete-incident="${protegerTexto(i.id)}" class="text-red-600 underline">Excluir</button></div></article>`).join("") || "<p>Nenhuma ocorrência cadastrada.</p>";
        }
    } catch(e) { mostrarMensagem(e.message); }
}
document.getElementById("adminList").addEventListener("click", async function(e) {
    const editUser=e.target.closest("[data-user-edit]"), delUser=e.target.closest("[data-user-delete]");
    try {
      if (editUser) {
        const id=editUser.dataset.userEdit, name=prompt("Novo nome:"), email=prompt("Novo e-mail:");
        if(name===null||email===null)return;
        const role=prompt("Perfil: user ou admin (digite exatamente):","user");
        const password=prompt("Nova senha (deixe vazio para manter):") || "";
        await requisicaoAPI("/users/"+encodeURIComponent(id),{method:"PATCH",body:JSON.stringify({name,email,role,password})});
        mostrarMensagem("Usuário atualizado."); carregarPainelAdmin();
      }
      if (delUser) {
        if(!confirm("Confirma a exclusão deste usuário?"))return;
        await requisicaoAPI("/users/"+encodeURIComponent(delUser.dataset.userDelete),{method:"DELETE"});
        mostrarMensagem("Usuário excluído."); carregarPainelAdmin();
      }
    } catch(err) { mostrarMensagem(err.message); }
});
document.addEventListener("click", async function(e) {
    const trafficEdit = e.target.closest("[data-edit-traffic]");
    const trafficDelete = e.target.closest("[data-delete-traffic]");
    if (trafficEdit || trafficDelete) {
        const id = (trafficEdit || trafficDelete).dataset.editTraffic || (trafficEdit || trafficDelete).dataset.deleteTraffic;
        const item = trafficData.find(x => x.id === id);
        if (!item) return;
        if (trafficDelete) {
            if (!confirm("Confirma a exclusão desta situação do trânsito?")) return;
            try {
                await requisicaoAPI("/traffic-status/" + encodeURIComponent(id), { method: "DELETE" });
                await carregarTransito();
                mostrarMensagem("Situação do trânsito excluída.");
            } catch (err) { mostrarMensagem(err.message); }
            return;
        }
        const local = prompt("Local:", item.local);
        const status = local === null ? null : prompt("Status (Normal, Atenção ou Intenso):", item.status);
        const detail = status === null ? null : prompt("Descrição:", item.detail);
        if (local === null || status === null || detail === null) return;
        try {
            await requisicaoAPI("/traffic-status/" + encodeURIComponent(id), {
                method: "PATCH",
                body: JSON.stringify({ local, status, detail })
            });
            await carregarTransito();
            mostrarMensagem("Situação do trânsito atualizada.");
        } catch (err) { mostrarMensagem(err.message); }
        return;
    }

    const edit=e.target.closest("[data-edit-incident]"), del=e.target.closest("[data-delete-incident]");
    if(!edit&&!del)return;
    const id=(edit||del).dataset.editIncident || (edit||del).dataset.deleteIncident;
    const item=ocorrencias.find(x=>x.id===id);
    if(del) {
      if(!confirm("Confirma a exclusão desta ocorrência?"))return;
      try { await requisicaoAPI("/incidents/"+encodeURIComponent(id),{method:"DELETE"}); await carregarOcorrencias(); if(usuarioAtual?.role==="admin"&&abaAdmin==="incidents")carregarPainelAdmin(); mostrarMensagem("Ocorrência excluída."); }
      catch(err){mostrarMensagem(err.message);}
      return;
    }
    if(!item && usuarioAtual?.role!=="admin"){mostrarMensagem("Atualize a lista para editar esta ocorrência.");return;}
    const base=item||{};
    const type=prompt("Tipo:",base.incidentType||"Ocorrência"), local=prompt("Local:",base.local||""), date=prompt("Data (AAAA-MM-DD):",base.date||""), time=prompt("Horário:",base.time||""), description=prompt("Descrição:",base.description||"");
    if([type,local,date,time,description].some(v=>v===null))return;
    try { await requisicaoAPI("/incidents/"+encodeURIComponent(id),{method:"PATCH",body:JSON.stringify({type,local,date,time,description})}); await carregarOcorrencias(); if(usuarioAtual?.role==="admin"&&abaAdmin==="incidents")carregarPainelAdmin(); mostrarMensagem("Ocorrência atualizada."); }
    catch(err){mostrarMensagem(err.message);}
});
const originalMostrarPagina = mostrarPagina;
mostrarPagina = function(pagina) {
    originalMostrarPagina(pagina);
    if(pagina==="profilePage") atualizarAcesso();
    if(pagina==="adminPage") carregarPainelAdmin();
};

// Coloca a data de hoje no formulário
const hoje = new Date();
const ano = hoje.getFullYear();
const mes = String(hoje.getMonth() + 1).padStart(2, "0");
const dia = String(hoje.getDate()).padStart(2, "0");

document.getElementById("incidentDate").value = ano + "-" + mes + "-" + dia;

// Mostra o trânsito quando a página abre
mostrarTransito();


// Recupera a sessão ao atualizar a página.
(async function restaurarSessao() {
    if (!tokenSessao) return;
    try {
        const sessao = await requisicaoAPI("/auth/me");
        usuarioAtual = sessao.user;
        atualizarAcesso();
        document.getElementById("loginView").classList.add("hidden");
        document.getElementById("mainView").classList.remove("hidden");
        mostrarPagina("homePage");
        await carregarOcorrencias();
        await carregarTransito();
    } catch (_erro) {
        tokenSessao = "";
        localStorage.removeItem("viaNorteToken");
    }
})();
