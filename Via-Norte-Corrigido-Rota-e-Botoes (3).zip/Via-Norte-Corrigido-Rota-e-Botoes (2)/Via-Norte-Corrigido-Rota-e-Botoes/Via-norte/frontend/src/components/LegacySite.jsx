import { useEffect } from 'react';
import markup from '../legacySite.html?raw';

export default function LegacySite() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/site/script.js';
    script.dataset.viaNorte = 'true';
    document.body.appendChild(script);
    return () => script.remove();
  }, []);
  return <div dangerouslySetInnerHTML={{ __html: markup }} />;
}
