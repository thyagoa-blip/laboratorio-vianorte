// A página original de ocorrências permanece no HTML legado, sem alterações visuais.
export default function IncidentPage() { return null; }
