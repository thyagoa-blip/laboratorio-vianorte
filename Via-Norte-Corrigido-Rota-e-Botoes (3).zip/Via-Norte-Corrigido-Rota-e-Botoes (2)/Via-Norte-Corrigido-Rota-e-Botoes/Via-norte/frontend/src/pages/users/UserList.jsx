// Gerenciamento administrativo de usuários continua no painel original.
export default function UserList() { return null; }
