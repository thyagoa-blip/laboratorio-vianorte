export default function Home() { return <div id="via-norte-original-root" />; }
