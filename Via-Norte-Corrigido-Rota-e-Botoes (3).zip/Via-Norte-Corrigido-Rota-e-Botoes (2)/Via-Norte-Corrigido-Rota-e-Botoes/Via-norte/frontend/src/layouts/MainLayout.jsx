import { useEffect } from 'react';

export default function MainLayout({ children }) {
  useEffect(() => { document.documentElement.lang = 'pt-BR'; }, []);
  return <div className="via-norte-app">{children}</div>;
}
