import LegacySite from './components/LegacySite.jsx';
import MainLayout from './layouts/MainLayout.jsx';

export default function App() {
  return <MainLayout><LegacySite /></MainLayout>;
}
