
import crypto from 'node:crypto';

function segredo() {
  return process.env.JWT_SECRET || 'chave-local-vianorte';
}

export function createToken(user) {
  const payload = Buffer.from(
    JSON.stringify({
      id: user.id,
      role: user.role,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
    })
  ).toString('base64url');

  const signature = crypto
    .createHmac('sha256', segredo())
    .update(payload)
    .digest('base64url');

  return `${payload}.${signature}`;
}

export function readToken(req) {
  const authorization = req.headers.authorization;

  if (!authorization?.startsWith('Bearer ')) {
    return null;
  }

  const token = authorization.slice(7);
  const [payload, signature] = token.split('.');

  if (!payload || !signature) return null;

  const expected = crypto
    .createHmac('sha256', segredo())
    .update(payload)
    .digest();

  let received;

  try {
    received = Buffer.from(signature, 'base64url');
  } catch {
    return null;
  }

  if (
    received.length !== expected.length ||
    !crypto.timingSafeEqual(received, expected)
  ) {
    return null;
  }

  try {
    const session = JSON.parse(
      Buffer.from(payload, 'base64url').toString('utf8')
    );

    if (!session.id || session.expiresAt < Date.now()) {
      return null;
    }

    return session;
  } catch {
    return null;
  }
}
