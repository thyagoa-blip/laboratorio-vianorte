import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';

async function hashPassword(password) {
    return bcrypt.hash(password, 10);
}

async function verifyPassword(password, storedPassword) {
    const stored = String(storedPassword || '');

    // Compatibilidade com senhas já cadastradas no antigo armazenamento JSON.
    if (stored.includes(':')) {
        const [salt, originalHash] = stored.split(':');
        if (!salt || !originalHash) return false;

        const actualHash = Buffer.from(
            crypto.scryptSync(password, salt, 64).toString('hex'),
            'hex'
        );
        const expectedHash = Buffer.from(originalHash, 'hex');

        return actualHash.length === expectedHash.length &&
            crypto.timingSafeEqual(actualHash, expectedHash);
    }

    return bcrypt.compare(password, stored);
}

export { hashPassword, verifyPassword };
