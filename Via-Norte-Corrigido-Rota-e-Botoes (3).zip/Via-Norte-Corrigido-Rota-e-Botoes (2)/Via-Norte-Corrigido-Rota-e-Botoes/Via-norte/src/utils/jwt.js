import crypto from 'node:crypto';

const SECRET = process.env.JWT_SECRET ||
    'chave-local-via-norte-altere-antes-de-publicar';

function createToken(user) {
    const payload = Buffer.from(JSON.stringify({
        id: user.id,
        exp: Date.now() + 8 * 60 * 60 * 1000
    })).toString('base64url');

    const signature = crypto
        .createHmac('sha256', SECRET)
        .update(payload)
        .digest('base64url');

    return `${payload}.${signature}`;
}

function readToken(req) {
    const token = String(req.headers.authorization || '')
        .replace(/^Bearer\s+/i, '');

    const [payload, signature] = token.split('.');

    if (!payload || !signature) {
        return null;
    }

    const expected = crypto
        .createHmac('sha256', SECRET)
        .update(payload)
        .digest();

    const received = Buffer.from(signature, 'base64url');

    if (received.length !== expected.length ||
        !crypto.timingSafeEqual(received, expected)) {
        return null;
    }

    try {
        const session = JSON.parse(Buffer.from(payload, 'base64url').toString());
        return session.exp > Date.now() ? session : null;
    } catch {
        return null;
    }
}

export { createToken, readToken };
