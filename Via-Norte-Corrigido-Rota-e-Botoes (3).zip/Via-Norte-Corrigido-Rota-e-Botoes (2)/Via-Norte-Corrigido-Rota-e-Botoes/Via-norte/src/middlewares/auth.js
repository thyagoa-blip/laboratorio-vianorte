import createError from '../utils/createError.js';
import { prisma } from '../lib/prisma.js';
import { readToken } from '../utils/token.js';

async function autenticar(req, res, next) {
    try {
        const session = readToken(req);

        if (!session) {
            return next(createError(401, 'Faça login para continuar.'));
        }

        const user = await prisma.user.findUnique({
            where: { id: session.id }
        });

        if (!user) {
            return next(createError(401, 'Sessão inválida.'));
        }

        req.user = user;
        next();
    } catch (error) {
        next(error);
    }
}

function somenteAdmin(req, res, next) {
    if (req.user?.role !== 'admin') {
        return next(createError(403, 'Acesso exclusivo do administrador.'));
    }

    next();
}

export { autenticar, somenteAdmin };
