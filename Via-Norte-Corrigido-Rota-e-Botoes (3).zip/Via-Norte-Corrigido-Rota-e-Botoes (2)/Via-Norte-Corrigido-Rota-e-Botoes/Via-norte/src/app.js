import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { prismaErrorHandler } from './lib/prisma.js';

import indexRouter from './routes/index.js';
import authRouter from './routes/auth.js';
import usersRouter from './routes/users.js';
import incidentsRouter from './routes/incidents.js';
import trafficStatusRouter from './routes/trafficStatus.js';

import createError from './utils/createError.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, '..');
const SITE_DIR = path.join(ROOT_DIR, 'public', 'site');

const app = express();

if (process.env.NODE_ENV !== 'production') {
    app.use(morgan('dev'));
}

app.use(cors());
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false }));

app.use('/', indexRouter);
app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/incidents', incidentsRouter);
app.use('/api/traffic-status', trafficStatusRouter);

// Mantém os arquivos originais do site sem alterar sua aparência.
app.use(express.static(SITE_DIR));
app.get('/', (req, res) => {
    res.sendFile(path.join(SITE_DIR, 'index.html'));
});

app.use((req, res, next) => {
    next(createError(404, 'Rota não encontrada.'));
});

app.use((err, req, res, next) => {
    console.error(err);
    const error = prismaErrorHandler(err);
    const statusCode = error.status || err.status || 500;

    res.status(statusCode).json({
        error: statusCode !== 500
            ? error.message || err.message
            : 'Erro interno do servidor.'
    });
});

export default app;
