import 'dotenv/config';

import app from './app.js';

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
    console.log(`Via Norte executando em http://127.0.0.1:${PORT}`);
});
