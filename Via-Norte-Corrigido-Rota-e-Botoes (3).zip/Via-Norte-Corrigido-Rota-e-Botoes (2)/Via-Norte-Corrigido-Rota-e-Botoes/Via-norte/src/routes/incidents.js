import { Router } from 'express';

import createError from '../utils/createError.js';
import { prisma } from '../lib/prisma.js';
import { autenticar } from '../middlewares/auth.js';

const router = Router();

function validarOcorrencia(data) {
    return ['type', 'local', 'date', 'time', 'description'].every(key =>
        typeof data[key] === 'string' && data[key].trim()
    ) && data.description.trim().length <= 500;
}

router.use(autenticar);

// GET /api/incidents
router.get('/', async (req, res) => {
    const incidents = await prisma.incident.findMany({
        orderBy: { createdAt: 'desc' }
    });
    res.json({ incidents });
});

// POST /api/incidents
router.post('/', async (req, res) => {
    const data = req.body || {};
    if (!validarOcorrencia(data)) {
        throw createError(400, 'Preencha todos os campos. A descrição deve ter até 500 caracteres.');
    }

    const incident = await prisma.incident.create({
        data: {
            title: `${data.type.trim()} - ${data.local.trim()}`,
            type: 'Ocorrência',
            incidentType: data.type.trim(),
            local: data.local.trim(),
            status: 'Registrada',
            date: data.date,
            time: data.time,
            description: data.description.trim(),
            user: { connect: { id: req.user.id } }
        }
    });

    res.status(201).json({ incident });
});

// PATCH /api/incidents/:id
router.patch('/:id', async (req, res) => {
    const incident = await prisma.incident.findUniqueOrThrow({
        where: { id: req.params.id }
    });

    const data = req.body || {};
    const merged = {
        type: data.type ?? incident.incidentType,
        local: data.local ?? incident.local,
        date: data.date ?? incident.date,
        time: data.time ?? incident.time,
        description: data.description ?? incident.description
    };

    if (!validarOcorrencia(merged)) {
        throw createError(400, 'Dados da ocorrência inválidos.');
    }

    const updated = await prisma.incident.update({
        where: { id: req.params.id },
        data: {
            incidentType: merged.type.trim(),
            title: `${merged.type.trim()} - ${merged.local.trim()}`,
            local: merged.local.trim(),
            date: merged.date,
            time: merged.time,
            description: merged.description.trim()
        }
    });

    res.json({ incident: updated });
});

// DELETE /api/incidents/:id
router.delete('/:id', async (req, res) => {
    const incident = await prisma.incident.findUniqueOrThrow({
        where: { id: req.params.id }
    });

    await prisma.incident.delete({ where: { id: req.params.id } });
    res.json({ message: 'Ocorrência excluída.' });
});

export default router;
