import { Router } from 'express';
import crypto from 'node:crypto';

import createError from '../utils/createError.js';
import { prisma } from '../lib/prisma.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { createToken } from '../utils/jwt.js';
import { autenticar } from '../middlewares/auth.js';

const router = Router();
const codigosRecuperacao = new Map();

function usuarioSeguro(usuario) {
    const { password, ...dados } = usuario;
    return dados;
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
    const data = req.body || {};
    const name = String(data.name || '').trim();
    const email = String(data.email || '').trim().toLowerCase();
    const password = String(data.password || '');

    if (name.length < 3 || name.length > 80) {
        throw createError(400, 'Informe um nome entre 3 e 80 caracteres.');
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
        throw createError(400, 'E-mail inválido.');
    }
    if (password.length < 8 || password.length > 128) {
        throw createError(400, 'A senha precisa ter entre 8 e 128 caracteres.');
    }

    const user = await prisma.user.create({
        data: {
            name,
            email,
            password: await hashPassword(password),
            role: 'user'
        }
    });

    res.status(201).json({
        token: createToken(user),
        user: usuarioSeguro(user)
    });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
    const data = req.body || {};
    const email = String(data.email || '').trim().toLowerCase();
    const password = String(data.password || '');

    const user = await prisma.user.findUnique({ where: { email } });

    if (!user || !(await verifyPassword(password, user.password))) {
        throw createError(401, 'E-mail ou senha incorretos.');
    }

    // Senhas antigas eram armazenadas com scrypt; após login, passam para bcrypt.
    if (user.password.includes(':')) {
        await prisma.user.update({
            where: { id: user.id },
            data: { password: await hashPassword(password) }
        });
    }

    res.json({
        token: createToken(user),
        user: usuarioSeguro(user)
    });
});

// GET /api/auth/me
router.get('/me', autenticar, (req, res) => {
    res.json({ user: usuarioSeguro(req.user) });
});

// PATCH /api/auth/me
router.patch('/me', autenticar, async (req, res) => {
    const data = req.body || {};
    const name = String(data.name || '').trim();
    const email = String(data.email || '').trim().toLowerCase();

    if (name.length < 3 || name.length > 80 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        throw createError(400, 'Informe nome e e-mail válidos.');
    }

    const updateData = { name, email };
    if (data.password) {
        const password = String(data.password);
        if (password.length < 8 || password.length > 128) {
            throw createError(400, 'A nova senha deve ter pelo menos 8 caracteres.');
        }
        updateData.password = await hashPassword(password);
    }

    const user = await prisma.user.update({
        where: { id: req.user.id },
        data: updateData
    });

    res.json({ user: usuarioSeguro(user) });
});

// POST /api/auth/forgot
router.post('/forgot', async (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const user = await prisma.user.findUnique({ where: { email } });

    if (user) {
        const code = String(crypto.randomInt(100000, 999999));
        codigosRecuperacao.set(email, {
            code,
            expires: Date.now() + 15 * 60 * 1000
        });
        console.log(`[Via Norte] Código temporário de recuperação para ${email}: ${code}`);
    }

    res.json({
        message: 'Se o e-mail estiver cadastrado, um código temporário será exibido no terminal do servidor (válido por 15 minutos).'
    });
});

// POST /api/auth/reset
router.post('/reset', async (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const code = String(req.body?.code || '');
    const password = String(req.body?.password || '');
    const saved = codigosRecuperacao.get(email);

    if (!saved || saved.expires < Date.now() || saved.code !== code) {
        throw createError(400, 'Código inválido ou expirado. Solicite outro.');
    }
    if (password.length < 8 || password.length > 128) {
        throw createError(400, 'A nova senha deve ter pelo menos 8 caracteres.');
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw createError(400, 'Conta não encontrada.');

    await prisma.user.update({
        where: { id: user.id },
        data: { password: await hashPassword(password) }
    });
    codigosRecuperacao.delete(email);

    res.json({ message: 'Senha alterada com sucesso. Faça login.' });
});

export default router;
