import { Router } from 'express';

import createError from '../utils/createError.js';
import { prisma } from '../lib/prisma.js';
import { hashPassword } from '../utils/password.js';
import { autenticar, somenteAdmin } from '../middlewares/auth.js';

const router = Router();

const userFilter = {
    id: true,
    name: true,
    email: true,
    role: true,
    createdAt: true
};

router.use(autenticar, somenteAdmin);

// GET /api/users
router.get('/', async (req, res) => {
    const users = await prisma.user.findMany({
        select: userFilter,
        orderBy: { createdAt: 'desc' }
    });
    res.json({ users });
});

// PATCH /api/users/:id
router.patch('/:id', async (req, res) => {
    const data = req.body || {};
    const id = req.params.id;

    const user = await prisma.user.findUniqueOrThrow({ where: { id } });
    const name = String(data.name || user.name).trim();
    const email = String(data.email || user.email).trim().toLowerCase();

    if (name.length < 3 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        throw createError(400, 'Nome ou e-mail inválido.');
    }

    const novoPerfil = data.role === 'admin' || data.role === 'user'
        ? data.role
        : user.role;

    if (user.role === 'admin' && novoPerfil === 'user') {
        const admins = await prisma.user.count({ where: { role: 'admin' } });
        if (admins <= 1) {
            throw createError(400, 'Não é possível rebaixar o último administrador.');
        }
    }

    if (user.id === req.user.id && novoPerfil !== 'admin') {
        throw createError(400, 'Você não pode remover seu próprio acesso administrativo.');
    }

    const updateData = { name, email, role: novoPerfil };
    if (data.password) {
        const password = String(data.password);
        if (password.length < 8 || password.length > 128) {
            throw createError(400, 'Senha deve ter ao menos 8 caracteres.');
        }
        updateData.password = await hashPassword(password);
    }

    const updated = await prisma.user.update({
        where: { id },
        data: updateData,
        select: userFilter
    });

    res.json({ user: updated });
});

// DELETE /api/users/:id
router.delete('/:id', async (req, res) => {
    const id = req.params.id;
    const user = await prisma.user.findUniqueOrThrow({ where: { id } });

    if (user.id === req.user.id) {
        throw createError(400, 'Você não pode excluir sua própria conta administrativa.');
    }

    if (user.role === 'admin') {
        const admins = await prisma.user.count({ where: { role: 'admin' } });
        if (admins <= 1) {
            throw createError(400, 'Não é possível excluir o último administrador.');
        }
    }

    await prisma.user.delete({ where: { id } });
    res.json({ message: 'Usuário excluído.' });
});

export default router;
