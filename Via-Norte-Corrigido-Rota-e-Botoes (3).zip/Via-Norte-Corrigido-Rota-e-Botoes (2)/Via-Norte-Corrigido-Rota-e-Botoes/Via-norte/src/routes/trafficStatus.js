import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import createError from '../utils/createError.js';
import { prisma } from '../lib/prisma.js';
import { autenticar } from '../middlewares/auth.js';

const router = Router();
router.use(autenticar);

const defaults = [
  { local: 'Centro', status: 'Intenso', detail: 'Trânsito intenso', updated: '14:20' },
  { local: 'Martim de Sá', status: 'Atenção', detail: 'Atenção na via', updated: '14:05' },
  { local: 'Indaiá', status: 'Normal', detail: 'Trânsito normal', updated: '13:50' },
  { local: 'Massaguaçu', status: 'Intenso', detail: 'Trânsito intenso', updated: '14:10' },
  { local: 'Perequê-Mirim', status: 'Normal', detail: 'Trânsito normal', updated: '13:45' },
  { local: 'Porto-Novo', status: 'Atenção', detail: 'Atenção na via', updated: '13:08' },
  { local: 'Sumaré', status: 'Normal', detail: 'Trânsito normal', updated: '14:24' },
  { local: 'Praia das Palmeiras', status: 'Atenção', detail: 'Atenção na via', updated: '13:00' },
  { local: 'Tinga', status: 'Normal', detail: 'Trânsito normal', updated: '13:13' },
  { local: 'Golfinho', status: 'Normal', detail: 'Trânsito normal', updated: '14:22' },
  { local: 'Pontal de Santa Marina', status: 'Atenção', detail: 'Atenção na via', updated: '14:40' }
];

function validar(data) {
  const allowed = ['Normal', 'Atenção', 'Intenso'];
  if (typeof data.local !== 'string' || !data.local.trim() ||
      typeof data.status !== 'string' || !allowed.includes(data.status) ||
      typeof data.detail !== 'string' || !data.detail.trim()) {
    throw createError(400, 'Informe local, status válido e descrição.');
  }
}

router.get('/', async (_req, res) => {
  let rows = await prisma.trafficStatus.findMany({ orderBy: { local: 'asc' } });
  if (rows.length === 0) {
    await prisma.trafficStatus.createMany({
      data: defaults.map(item => ({ id: randomUUID(), ...item }))
    });
    rows = await prisma.trafficStatus.findMany({ orderBy: { local: 'asc' } });
  }
  res.json({ trafficStatus: rows });
});

router.patch('/:id', async (req, res) => {
  const current = await prisma.trafficStatus.findUnique({ where: { id: req.params.id } });
  if (!current) throw createError(404, 'Situação do trânsito não encontrada.');
  const data = {
    local: req.body.local ?? current.local,
    status: req.body.status ?? current.status,
    detail: req.body.detail ?? current.detail
  };
  validar(data);
  const updated = await prisma.trafficStatus.update({
    where: { id: req.params.id },
    data: { ...data, local: data.local.trim(), detail: data.detail.trim(), updated: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) }
  });
  res.json({ trafficStatus: updated });
});

router.delete('/:id', async (req, res) => {
  const current = await prisma.trafficStatus.findUnique({ where: { id: req.params.id } });
  if (!current) throw createError(404, 'Situação do trânsito não encontrada.');
  await prisma.trafficStatus.delete({ where: { id: req.params.id } });
  res.json({ message: 'Situação do trânsito excluída.' });
});

export default router;
