import { Router } from 'express';

const router = Router();

const status = {
    status: 'ok',
    api: 'Via Norte'
};

// GET /
router.get('/api/health', (req, res) => {
    res.set('Cache-Control', 'no-store');
    status.timestamp = new Date().toISOString();
    res.json(status);
});

export default router;
