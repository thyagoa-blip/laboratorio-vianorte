-- Initial Via Norte database migration (MySQL / MariaDB)
CREATE TABLE `users` (
  `id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'user',
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  UNIQUE INDEX `users_email_key`(`email`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `incidents` (
  `id` VARCHAR(36) NOT NULL,
  `title` VARCHAR(180) NOT NULL,
  `type` VARCHAR(40) NOT NULL DEFAULT 'Ocorrência',
  `incidentType` VARCHAR(80) NOT NULL,
  `local` VARCHAR(180) NOT NULL,
  `status` VARCHAR(40) NOT NULL DEFAULT 'Registrada',
  `date` VARCHAR(20) NOT NULL,
  `time` VARCHAR(10) NOT NULL,
  `description` VARCHAR(500) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  `createdBy` VARCHAR(36) NULL,
  INDEX `incidents_createdBy_idx`(`createdBy`),
  PRIMARY KEY (`id`),
  CONSTRAINT `incidents_createdBy_fkey`
    FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
